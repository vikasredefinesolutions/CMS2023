export const type1 = '1'
export const type2 = '2'
export const type3 = '3'