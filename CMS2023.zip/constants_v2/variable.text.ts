export const __variableText = {};
