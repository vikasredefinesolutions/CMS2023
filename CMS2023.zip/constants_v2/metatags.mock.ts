// export const metatagsdata = [
//   {
//     tagName: 'twitter',
//     tagSite: '@corporategear_usa',
//   },
// ];
export const TwitterTagsData = {
  tagName: 'twitter',
  tagSite: '@corporategear_usa',
};
export const OgTagsData = {
  latitude: `41.580093`,
  longitude: `-71.477432`,
  street_address: `2290 Pawtucket Avenue`,
  locality: `East Providence`,
  region: `RI`,
  postal_code: `02914`,
  country_name: 'USA',
};
