interface brandType {
  brandId?: number | string;
  storeId: number | null;
  maximumItemsForFetch: number | string;
  tagName: string;
}
