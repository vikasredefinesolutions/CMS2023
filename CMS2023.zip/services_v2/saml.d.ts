export interface _profileModel {
  storeId: number;
  base64SAMLResponse: string;
}
