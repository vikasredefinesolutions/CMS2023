import CustomRequestTemplate from '@templates/CustomRequestForm';
import { NextPage } from 'next';

const CustomeRequest: NextPage = () => {
  return <CustomRequestTemplate id={'1'} />;
};

export default CustomeRequest;
