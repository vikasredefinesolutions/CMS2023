const logos = {
  primaryLogo: {
    url: '',
    alt: '',
  },
  secondaryLogo: {
    url: '',
    alt: '',
  },
  title: "Men's Custom Clothing",
  subTitle: 'Name Brand Logo Apparel & Company Clothing',
  description: `Custom clothing and logo apparel adds timeless style to men's promotional apparel. Customize company clothing from name brands like Nike, Peter Millar, FootJoy, Adidas, Helly Hansen, The North Face, Johnnie-O, Southern Tide and more.`,
};

export default logos;
