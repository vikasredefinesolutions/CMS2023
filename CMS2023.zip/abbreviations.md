SU => SignUp
RC => RequestConsultation
OL => OrdersList
OrD => OrderDetails
RP => ResetPassword
SD => StoryDetails
SL => StoryList
SC => StoryCategory

------------------------------------------APIs-----------------------------------------
CNA => CreateNewAccount
