export type _FileUpload = {
  file: File;
  response: any;
  preview: string;
};
