// import bannerMock from '../mock/banner.mock';
import bannerMock from '../mock_v2/banner.mock';
export type _ProductListBanner = typeof bannerMock;
