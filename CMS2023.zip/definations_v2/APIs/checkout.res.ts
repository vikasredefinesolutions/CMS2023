export interface CheckCustomerAlreadyExistResponse {
  id: number;
  isCustomerExist: boolean;
  isGuestCustomer: boolean;
}
