export type CategoriesByPid = {
  id: number;
  name: string;
  sename: string;
}[];
