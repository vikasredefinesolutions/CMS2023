export interface _CustomerChangePassword {
  storeId: number;
  email: string;
}

export interface _GetCustomerRoles {
  storeId: number;
}
