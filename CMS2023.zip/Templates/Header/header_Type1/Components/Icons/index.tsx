import CloseIcon from '@header/header_Type1/Components/Icons/Header_CloseIcon';
import LoggedInMenu from '@header/header_Type1/Components/Icons/Header_LoggedInMenu';
import LoginIcon from '@header/header_Type1/Components/Icons/Header_LoginIcon';
import Logo from '@header/header_Type1/Components/Icons/Header_Logo';
import MenuIcon from '@header/header_Type1/Components/Icons/Header_MenuIcon';
import MyCartIcon from '@header/header_Type1/Components/Icons/Header_MyCartIcon';
import WishListIcon from '@header/header_Type1/Components/Icons/Header_WishListIcon';

export {
  LoginIcon,
  MenuIcon,
  WishListIcon,
  CloseIcon,
  Logo,
  MyCartIcon,
  LoggedInMenu,
};

