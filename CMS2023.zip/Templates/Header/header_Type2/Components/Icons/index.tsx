import CompareIcon from '@header/header_Type2/Components/Icons//Header_CompareIcon';
import CloseIcon from '@header/header_Type2/Components/Icons/Header_CloseIcon';
import LoggedInMenu from '@header/header_Type2/Components/Icons/Header_LoggedInMenu';
import LoginIcon from '@header/header_Type2/Components/Icons/Header_LoginIcon';
import Logo from '@header/header_Type2/Components/Icons/Header_Logo';
import MenuIcon from '@header/header_Type2/Components/Icons/Header_MenuIcon';
import MyCartIcon from '@header/header_Type2/Components/Icons/Header_MyCartIcon';

export {
  LoginIcon,
  MenuIcon,
  CloseIcon,
  Logo,
  MyCartIcon,
  LoggedInMenu,
  CompareIcon,
};
