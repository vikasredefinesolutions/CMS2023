import MyAccountSetting_Type2 from './components/MyAccountSetting_Type2';

const AccountTemplatesType2 = () => {
  return (
    <>
      <MyAccountSetting_Type2 />
    </>
  );
};

export default AccountTemplatesType2;
