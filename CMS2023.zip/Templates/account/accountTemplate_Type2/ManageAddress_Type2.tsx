import ManageAddress_Type2 from './components/ManageAddress_Type2';

const ManageAddressTemplate_Type2 = () => {
  return (
    <>
      <ManageAddress_Type2 />
    </>
  );
};

export default ManageAddressTemplate_Type2;
