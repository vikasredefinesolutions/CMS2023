import MyAccountTabType1 from '@appComponents/common/MyAccountTabsType1';
import ManageAddress from './components/ManageAddress';

const ManageAddressTemplate_Type1 = () => {
  return (
    <>
      <MyAccountTabType1 />
      <ManageAddress />
    </>
  );
};

export default ManageAddressTemplate_Type1;
