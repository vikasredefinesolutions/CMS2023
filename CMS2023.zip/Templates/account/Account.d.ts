import React from 'react';

export interface _AccountTemplates {
  type1: React.FC<_ListingProps>;
  type2: React.FC<_ListingProps>;
}

export interface _ListingProps {}
