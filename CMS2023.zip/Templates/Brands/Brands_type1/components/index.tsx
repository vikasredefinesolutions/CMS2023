import Br_Alphabets from './Br_Alphabets';
import Br_Banner from './Br_Banner';
import Br_Faq from './Br_Faq';

export { Br_Alphabets, Br_Banner, Br_Faq };
