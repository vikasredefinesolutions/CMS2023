export interface _CustomeRequestTemplates {
  type1: React.FC;
  type2: React.FC;
}
