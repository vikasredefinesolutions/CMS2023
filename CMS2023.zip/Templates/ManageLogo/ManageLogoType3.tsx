const ManageLogoType3 = () => {
    return <>manageLogo 3</>;
  };
  
  export default ManageLogoType3;
  