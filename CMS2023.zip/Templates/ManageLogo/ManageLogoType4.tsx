const ManageLogoType4 = () => {
    return <>manageLogo 4</>;
  };
  
  export default ManageLogoType4;
  