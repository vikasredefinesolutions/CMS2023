const CheckLogoApproved3 = () => {
  return <>Type 3</>;
};

export default CheckLogoApproved3;
