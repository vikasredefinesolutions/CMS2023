const CheckLogoApproved4 = () => {
  return <>CheckLogoApproved4</>;
};

export default CheckLogoApproved4;
