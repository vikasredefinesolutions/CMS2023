export interface _CheckLogoTemplates {
    type1: NextPage<>;
    type2: NextPage<>;
    type3: NextPage<>;
    type4: NextPage<>;
  }
  