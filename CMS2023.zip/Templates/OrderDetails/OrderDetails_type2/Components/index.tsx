import OrD_ItemDetails from './Ord_ItemDetails';
import Ord_PageTitle from './Ord_PageTitle';

export { Ord_PageTitle, OrD_ItemDetails };
