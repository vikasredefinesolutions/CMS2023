import React from 'react';

const Ord_PageTitle: React.FC = () => {
  return (
    <section className='pt-[40px]'>
      <div className='container mx-auto'>
        <div className='text-2xl-text text-center'>ORDERS</div>
      </div>
    </section>
  );
};

export default Ord_PageTitle;
