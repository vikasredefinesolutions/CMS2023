interface _OrderDetailsTemplates {
  type1: React.FC;
  type2: React.FC;
}
