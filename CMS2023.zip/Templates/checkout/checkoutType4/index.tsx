import React from 'react';

interface _Props {
  cartTemplateId: number;
}

const CheckoutType4: React.FC<_Props> = ({ cartTemplateId }) => {
  return <></>;
};

export default CheckoutType4;
