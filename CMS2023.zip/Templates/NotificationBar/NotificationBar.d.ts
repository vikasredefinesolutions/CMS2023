import { NextPage } from 'next';
export interface _NotificationBarProps {
  // id: number;
}

export interface _NotificationBarTemplates {
  type1: NextPage<_NotificationBarProps>;
  type2: NextPage<_NotificationBarProps>;
  // type3: NextPage<_NotificationBarProps, _NotificationBarProps>;
  // type4: NextPage<_NotificationBarProps, _NotificationBarProps>;
}
